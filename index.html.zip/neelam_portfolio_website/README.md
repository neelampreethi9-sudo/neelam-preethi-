# Neelam Preethi — Portfolio Website

A responsive one-page portfolio website built with plain HTML, CSS, and a small JavaScript snippet.

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in any modern web browser.

## Customize
- Update the text in `index.html` as you gain more project or experience details.
- The email links already use `neelampreethi9@gmail.com`.
- No external libraries or build tools are required.

## Publish online
Upload `index.html` to a static hosting service such as GitHub Pages, Netlify, or Vercel. Review the hosting service's current instructions before publishing.

All content is limited to details supplied by Neelam Preethi. Missing project and freelancing details are explicitly left unspecified.
